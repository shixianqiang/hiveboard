//#ifndef _RT5621_H
//#define _RT5621_H




extern struct snd_soc_dai cs3700_dai;	
extern struct snd_soc_codec_device soc_codec_dev_cs3700;

//#endif
